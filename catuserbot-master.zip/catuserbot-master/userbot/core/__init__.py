from .decorators import check_owner

CMD_INFO = {}
PLG_INFO = {}
GRP_INFO = {}
BOT_INFO = []
LOADED_CMDS = {}
